import os
import threading
import requests

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.utils import platform

APP_NAME = "PRIYA"
API_KEY = os.environ.get("OPENAI_API_KEY", "").strip()

SYSTEM_PROMPT = (
    "Tum PRIYA ho, ek pyaari, smart aur caring Hindi/Hinglish AI assistant. "
    "User ko 'Sir' bolo. Jawab natural, friendly aur short rakho. "
    "Agar user Hindi me bole to Hindi/Hinglish me jawab do."
)

def android_speak(text):
    """Android Text-to-Speech; no internet TTS dependency required."""
    if platform != "android":
        return
    try:
        from jnius import autoclass, PythonJavaClass, java_method
        PythonActivity = autoclass("org.kivy.android.PythonActivity")
        TextToSpeech = autoclass("android.speech.tts.TextToSpeech")
        Locale = autoclass("java.util.Locale")

        class InitListener(PythonJavaClass):
            __javainterfaces__ = ["android/speech/tts/TextToSpeech$OnInitListener"]
            __javacontext__ = "app"
            def __init__(self, message):
                super().__init__()
                self.message = message
            @java_method("(I)V")
            def onInit(self, status):
                if status == TextToSpeech.SUCCESS:
                    self.tts.setLanguage(Locale("hi", "IN"))
                    self.tts.speak(self.message, TextToSpeech.QUEUE_FLUSH, None, "PRIYA")
        # Keep a reference so Java does not collect it.
        listener = InitListener(text)
        tts = TextToSpeech(PythonActivity.mActivity, listener)
        listener.tts = tts
        App.get_running_app()._tts = tts
        App.get_running_app()._tts_listener = listener
    except Exception as e:
        print("TTS error:", e)

def ask_openai(user_text):
    if not API_KEY:
        return "Sir, pehle OPENAI_API_KEY set karna hoga. README me iska simple tareeka diya hai."

    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "temperature": 0.7,
    }
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=45)
        r.raise_for_status()
        data = r.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return f"Sir, abhi connection me problem aa rahi hai. ({e})"

class PriyaApp(App):
    def build(self):
        Window.softinput_mode = "below_target"
        self.title = "PRIYA"
        self._tts = None
        self._tts_listener = None

        root = BoxLayout(orientation="vertical", padding=12, spacing=8)

        title = Label(
            text="[b]💗 PRIYA[/b]\n[i]Your Personal AI Assistant[/i]",
            markup=True,
            font_size="24sp",
            size_hint_y=None,
            height=75,
        )
        root.add_widget(title)

        self.chat = Label(
            text="Priya: Hello Sir ❤️\nMain Priya hoon. Bataiye, kya help karu?",
            markup=True,
            halign="left",
            valign="top",
            text_size=(Window.width - 30, None),
        )
        self.chat.bind(texture_size=self._chat_size)
        root.add_widget(self.chat)

        bottom = BoxLayout(size_hint_y=None, height=55, spacing=6)
        self.input = TextInput(
            hint_text="Priya se kuch poochiye...",
            multiline=False,
            font_size="17sp",
        )
        self.input.bind(on_text_validate=self.send_message)
        send = Button(text="SEND", size_hint_x=None, width=90)
        send.bind(on_release=self.send_message)
        bottom.add_widget(self.input)
        bottom.add_widget(send)
        root.add_widget(bottom)

        Clock.schedule_once(lambda dt: android_speak(
            "Hello Sir, main Priya hoon. Bataiye kya help karu?"
        ), 0.7)
        return root

    def _chat_size(self, instance, value):
        instance.text_size = (Window.width - 30, None)

    def send_message(self, *_):
        text = self.input.text.strip()
        if not text:
            return
        self.input.text = ""
        self.chat.text += f"\n\n[b]Aap:[/b] {text}\n[i]Priya soch rahi hai...[/i]"
        threading.Thread(target=self._get_answer, args=(text,), daemon=True).start()

    def _get_answer(self, text):
        answer = ask_openai(text)
        Clock.schedule_once(lambda dt: self._show_answer(answer), 0)

    def _show_answer(self, answer):
        # Replace the temporary "thinking" line.
        current = self.chat.text
        marker = "\n[i]Priya soch rahi hai...[/i]"
        if marker in current:
            current = current.rsplit(marker, 1)[0]
        self.chat.text = current + f"\n[b]Priya:[/b] {answer}"
        threading.Thread(target=android_speak, args=(answer,), daemon=True).start()

    def on_stop(self):
        try:
            if self._tts:
                self._tts.stop()
                self._tts.shutdown()
        except Exception:
            pass

if __name__ == "__main__":
    PriyaApp().run()
