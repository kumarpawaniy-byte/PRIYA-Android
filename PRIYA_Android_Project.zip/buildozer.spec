[app]
title = PRIYA
package.name = priya
package.domain = com.priya.assistant
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,txt
version = 1.0
requirements = python3,kivy,requests,pyjnius
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
icon.filename = %(source.dir)s/priya/icon.png

[buildozer]
log_level = 2
warn_on_root = 1
