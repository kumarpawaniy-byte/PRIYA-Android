PRIYA Android Project
=====================

यह project Kivy + Buildozer के लिए तैयार किया गया है।

महत्वपूर्ण:
1. अपनी OpenAI API key इस ZIP में मत डालें और किसी को भेजें भी नहीं।
2. API key को सुरक्षित रखने के लिए environment variable इस्तेमाल करें।
3. Android पर Text-to-Speech फोन के Hindi voice engine से चलेगा।

APK बनाने के लिए Linux/WSL/Ubuntu सबसे आसान तरीका है:

    sudo apt update
    sudo apt install -y git zip unzip openjdk-17-jdk python3-pip
    pip install --upgrade buildozer cython
    cd PRIYA_Android_Project
    buildozer android debug

पहली build में काफी समय लग सकता है।
APK बनने के बाद वह bin/ folder में मिलेगा।

API key:
-----------
Build करते समय केवल अपने development environment में:
    export OPENAI_API_KEY="YOUR_KEY_HERE"

फिर:
    buildozer android debug

नोट:
-----
इस demo में API request सीधे फोन से OpenAI तक जाती है। Production app में
API key को APK के अंदर रखना सुरक्षित नहीं है, क्योंकि APK को decompile करके
key निकाली जा सकती है। Production के लिए अपना छोटा backend/proxy इस्तेमाल करें।

Pydroid 3:
-----------
यह project Pydroid 3 में सीधे APK बनाने के लिए नहीं है। Pydroid में Python
code test किया जा सकता है; APK packaging के लिए Buildozer/Android build
environment चाहिए।

नाम:
PRIYA — Your Personal AI Assistant
